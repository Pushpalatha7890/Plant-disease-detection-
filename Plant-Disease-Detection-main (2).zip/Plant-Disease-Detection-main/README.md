# Plant 🌱 Disease 🐛 Detection 🔎
